﻿Imports System.IO
Imports System.Web
Imports System.Net.Mail
Imports System.Security.Cryptography

Public Class API

    Private Const STRING_NOT_FOUND As String = "N/A"
    Public Const ENABLED As String = "1"
    Public Const DISABLED As String = "0"
    Public Const ADMIN As Integer = 1
    Public Const USER As Integer = 2
    Private Const SYSTEMEMAIL As String = "philippet@gmail.com"
    Private Const EMAILSUFFIX = "@hrsdc-rhdcc.gc.ca"

    Public Sub setLanguage(ByVal currLang As String)
        Try
            Select Case currLang
                Case "en"
                    HttpContext.Current.Session.Add("gLang", "en")
                Case "fr"
                    HttpContext.Current.Session.Add("gLang", "fr")
                Case Else
                    HttpContext.Current.Session.Add("gLang", "en")
            End Select
        Catch ex As NullReferenceException
            HttpContext.Current.Session.Add("gLang", "en")
        End Try

    End Sub

    Public Function getLanguage() As String

        If HttpContext.Current.Request.QueryString("l") IsNot Nothing Then
            setLanguage(HttpContext.Current.Request.QueryString("l"))
        End If

        If HttpContext.Current.Session.Item("gLang") Is Nothing Then
            setLanguage("en")
        End If
        Return HttpContext.Current.Session.Item("gLang")

    End Function

    Public Function getMatrix(ByVal id As String) As String

        Dim lookup As New MatrixDataContext()
        Dim tempID As String = id
        Dim results As IQueryable(Of String)
        If getLanguage().Equals("en") Then
            results = (From Matrix In lookup.Matrix_infos _
                            Where Matrix.ID = id _
                            Select Matrix.english)
            If results Is Nothing OrElse results.Count() = 0 Then
                Return STRING_NOT_FOUND
            End If
            Return results.FirstOrDefault()
        End If
        results = (From Matrix In lookup.Matrix_infos _
                        Where Matrix.ID = id _
                        Select Matrix.french)
        If results Is Nothing OrElse results.Count() = 0 Then
            Return STRING_NOT_FOUND
        End If
        Return results.FirstOrDefault()

    End Function

    Public Function getMemo(ByVal id As String) As String

        Dim lookup As New MatrixDataContext()
        Dim tempID As String = id

        If getLanguage().Equals("en") Then
            Dim results = (From Memo In lookup.Memo_infos _
                            Where Memo.ID = id _
                            Select Memo.english)
            If (results Is Nothing) OrElse (results.Count() = 0) Then
                Return STRING_NOT_FOUND
            End If
            Return results.FirstOrDefault()
        Else
            Dim results = (From Memo In lookup.Memo_infos _
                            Where Memo.ID = id _
                            Select Memo.french)
            If (results Is Nothing) OrElse (results.Count() = 0) Then
                Return STRING_NOT_FOUND
            End If
            Return results.FirstOrDefault()
        End If

    End Function

    Public Function checkUserExsists(ByVal username As String) As Boolean

        Dim lookup As New UsersDataContext()
        Dim results As IQueryable(Of Guid)
        results = (From Users In lookup.Users _
                        Where Users.UserName = username _
                        Select Users.ID)
        If results Is Nothing OrElse results.Count() = 0 Then
            Return False
        End If
        Return True

    End Function

    Public Function checkUserManager(ByVal username As String) As Boolean

        Dim lookup As New HRdataDataContext()
        Dim results As Guid
        Dim results2 As IQueryable(Of Guid)
        results = (From HR_Data In lookup.HR_Datas Where HR_Data.Auth = username Select HR_Data.ID).FirstOrDefault
        If results <> Guid.Empty Then
            results2 = (From HR_Data In lookup.HR_Datas Where HR_Data.ReportsTo = results Select HR_Data.ID)
            If results2.Count() >= 1 Then
                Return True
            End If
        End If
        Return False

    End Function

    Public Function getUserType(ByVal username As String) As Integer

        Dim lookup As New HRdataDataContext()
        Dim results As Integer
        results = (From HR_Data In lookup.HR_Datas Where HR_Data.Auth = username Select HR_Data.Type).FirstOrDefault
        Return results

    End Function


    Public Function createUser(Optional ByVal Name As String = "", Optional ByVal Email As String = "", Optional ByVal Username As String = "", Optional ByVal Password As String = "") As Boolean

        Dim db As New UsersDataContext()
        Dim newUser As New User

        If HttpContext.Current.User.Identity.IsAuthenticated Then
            newUser.ID = Guid.NewGuid()
            Dim tempEmail = HttpContext.Current.User.Identity.Name.ToString().Split("\")
            If tempEmail.Length > 1 Then
                Dim tempName = tempEmail(1).Replace(".", " ")
                Dim cultureInfo As New System.Globalization.CultureInfo("en-CA")

                If getLanguage().Equals("fr") Then
                    cultureInfo = New System.Globalization.CultureInfo("fr-CA")
                End If
                newUser.Name = cultureInfo.TextInfo.ToTitleCase(tempName)
                newUser.Email = tempEmail(1) + EMAILSUFFIX
            Else
                newUser.Name = "Unknown"
                newUser.Email = "Unknown"
            End If

            newUser.Auth = HttpContext.Current.User.Identity.Name.ToString()
            newUser.Active = True
            newUser.Role = USER

            db.Users.InsertOnSubmit(newUser)

            Try
                db.SubmitChanges()
                Return True
            Catch e As Exception
                Return False
            End Try
        End If

        Return False

    End Function


    Public Sub checkAuth()
        If HttpContext.Current.User.Identity.IsAuthenticated Then
            Dim lookup As New UsersDataContext()
            Dim results = (From Users In lookup.Users _
                            Where Users.Auth = HttpContext.Current.User.Identity.Name.ToString() _
                            Select Users.Name, Users.Email, Users.Role, Users.ID)
            If results IsNot Nothing And results.Count() > 0 Then
                System.Web.HttpContext.Current.Session("isUserlogged") = True
                System.Web.HttpContext.Current.Session("usersID") = results.FirstOrDefault.ID
                System.Web.HttpContext.Current.Session("usersName") = results.FirstOrDefault.Name
                System.Web.HttpContext.Current.Session("usersEmail") = results.FirstOrDefault.Email
                System.Web.HttpContext.Current.Session("usersRole") = results.FirstOrDefault.Role
            Else
                If createUser() Then
                    HttpContext.Current.Response.Redirect("index.aspx?user=new")
                End If
            End If
        End If
    End Sub

    Public Sub adminCheck()

        If HttpContext.Current.Request.QueryString("l") IsNot Nothing Then
            setLanguage(HttpContext.Current.Request.QueryString("l"))
        End If

        If System.Web.HttpContext.Current.Session IsNot Nothing Then
            If System.Web.HttpContext.Current.Session("usersRole") IsNot Nothing Then
                If Not System.Web.HttpContext.Current.Session("usersRole").Equals(ADMIN) Then
                    System.Web.HttpContext.Current.Response.Redirect("index.aspx")
                End If
            Else
                System.Web.HttpContext.Current.Response.Redirect("index.aspx")
            End If
        End If

    End Sub

    Public Function checkUserLogin(ByVal username As String, ByVal passwordInput As String) As Boolean

        Dim lookup As New UsersDataContext()
        Dim results = (From Users In lookup.Users _
                        Where Users.UserName = username And Users.Active = True _
                        Select Users.Password, Users.Salt, Users.Name, Users.Email, Users.Role, Users.ID)
        If results Is Nothing OrElse results.Count() = 0 Then
            Return False
        End If

        Dim correctHash = "1000:" + results.FirstOrDefault.Password + ":" + results.FirstOrDefault.Salt

        If PasswordHash.ValidatePassword(passwordInput, correctHash) Then
            System.Web.HttpContext.Current.Session("isUserlogged") = True
            System.Web.HttpContext.Current.Session("usersID") = results.FirstOrDefault.ID
            System.Web.HttpContext.Current.Session("usersName") = results.FirstOrDefault.Name
            System.Web.HttpContext.Current.Session("usersUsername") = username
            System.Web.HttpContext.Current.Session("usersEmail") = results.FirstOrDefault.Email
            System.Web.HttpContext.Current.Session("usersRole") = results.FirstOrDefault.Role
            Return True
        Else
            Return False
        End If

    End Function

    Public Function sendEmail(ByVal fromAddress As String, ByVal toAddress As String, ByVal subject As String, ByVal body As String) As String

        If fromAddress Is Nothing OrElse toAddress Is Nothing OrElse subject Is Nothing OrElse body Is Nothing Then
            Return Nothing
        End If

        Dim primaryServer As New SmtpClient(ConfigurationManager.AppSettings.Item("EmailServer"))
        Dim secondaryServer As New SmtpClient(ConfigurationManager.AppSettings.Item("SecondaryEmailServer"))
        Dim email As MailMessage = Nothing
        Try
            email = New MailMessage(fromAddress, toAddress, subject, body)
        Catch formatEx As FormatException
            Return Nothing
        Catch ex As Exception
            Return ex.ToString()
        End Try
        email.IsBodyHtml = True

        If (ConfigurationManager.AppSettings.Item("EmailFlag").ToString() = ENABLED) Then
            Try
                primaryServer.Send(email)
            Catch ex As SmtpException

                If (ex.StatusCode = SmtpStatusCode.GeneralFailure) Then
                    Try
                        secondaryServer.Send(email)
                    Catch ex2 As SmtpException
                        If (ex2.StatusCode = SmtpStatusCode.GeneralFailure) Then
                            Return ex2.ToString()
                        End If
                    Catch ex2_2 As Exception
                    End Try
                End If
            Catch ex_2 As Exception
            End Try
        End If
        Return Nothing
    End Function

End Class

