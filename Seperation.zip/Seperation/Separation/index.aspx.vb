﻿Imports PasswordHash

Public Class index
    Inherits System.Web.UI.Page
    Private api As New API()

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        litWelomeHeading.Text = api.getMatrix("WelcomeHeading")
        litManagerGuideStepOne.Text = api.getMemo("ManagerGuideStepOne")
        btnSubmitSeperationForMyself.Text = api.getMatrix("SubmitForMyself")
        btnSubmitSeperationForEmployee.Text = api.getMatrix("SubmitForEmployee")
        btnReviewAndApproveASeperation.Text = api.getMatrix("ReviewAndApproveASeperation")
        btnContinueASeperation.Text = api.getMatrix("ContinueASeperation")
        litEmployeeGuideStepOne.Text = api.getMemo("EmployeeGuideStepOne")
        btnSubmitSeperationForMyself.Text = api.getMatrix("SubmitForMyself")

        litErrorText.Text = ""
        Dim personalizedGreeting = ""

        api.checkAuth()

        If System.Web.HttpContext.Current.Session IsNot Nothing Then
            If System.Web.HttpContext.Current.Session("isUserlogged") IsNot Nothing Then
                If System.Web.HttpContext.Current.Session("isUserlogged").Equals(True) Then
                    Dim tempArray() = System.Web.HttpContext.Current.Session("usersName").ToString.Split(" ")
                    personalizedGreeting = tempArray(0).ToString + " "

                End If
            End If
        End If

        litWelcome.Text = api.getMatrix("Welcome.1") + " " + personalizedGreeting + api.getMatrix("Welcome.2")

        If Request.QueryString("user") IsNot Nothing Then
            If Request.QueryString("user").Equals("new") Then
                litNewUser.Text = api.getMatrix("newUser")
                'TODO: Maybe have a special guide for new users?
            End If
        End If

        If Request.QueryString("error") IsNot Nothing Then
            Dim errorString = Request.QueryString("error")
            litErrorText.Text += api.getMatrix(errorString)
            litErrorText.Visible = True
        End If

        'TODO: Establish if the user is a manager, employee, or delegate (admin assistant / BMS)
        'if manager?
        'if delegate?
        If api.checkUserManager(HttpContext.Current.User.Identity.Name.ToString()) Then
            litEmployeeGuideStepOne.Visible = False
            litManagerGuideStepOne.Visible = True
        Else
            litManagerGuideStepOne.Visible = False
            Select Case api.getUserType(HttpContext.Current.User.Identity.Name.ToString())
                Case 1
                    litEmployeeGuideStepOne.Text = litEmployeeGuideStepOne.Text.Replace("[INDIVIDUAL_TYPE]", "Indeterminate Employee")
                Case 4
                    litEmployeeGuideStepOne.Text = litEmployeeGuideStepOne.Text.Replace("[INDIVIDUAL_TYPE]", "Contingent Worker / Consultant ")
                    litEmployeeGuideStepOne.Text = litEmployeeGuideStepOne.Text.Replace("[INDIVIDUAL_TYPE]", "Contingent Worker / Consultant ")
            End Select


            litEmployeeGuideStepOne.Visible = True
        End If


        'if pending notifications?

        'if individuals last date close?

        'if submition returned to client?


        'else then employee/contingent worker?

        'what type?
        'Replace [INDIVIDUAL_TYPE] in litEmployeeGuideStepOne.text

    End Sub
End Class