﻿Public Class UserManagement
    Inherits System.Web.UI.Page
    Private api As New API()

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        api.adminCheck()

        litUserManagment.Text = api.getMatrix("UserManagement")

        If Not Page.IsPostBack Then

            Dim lookup As New UsersDataContext()
            Dim results = (From Users In lookup.Users _
                            Select Users.ID, Users.Name, Users.Email, Users.Role, Users.Active)

            If results IsNot Nothing OrElse results.Count() > 0 Then
                Dim usersInfo As String
                usersInfo = "<table class=""wb-tables table table-striped table-hover"" data-wb-tables='{ ""ordering"" : true }'>"
                usersInfo += "<thead>"
                usersInfo += "<tr>"
                usersInfo += "<th>" + api.getMatrix("Select") + "</th>"
                usersInfo += "<th>" + api.getMatrix("FullName") + "</th>"
                usersInfo += "<th>" + api.getMatrix("Email") + "</th>"
                usersInfo += "<th>" + api.getMatrix("Role") + "</th>"
                usersInfo += "<th>" + api.getMatrix("Active") + "</th>"
                usersInfo += "</tr>"
                usersInfo += "</thead>"
                usersInfo += "<tbody>"

                For Each item In results

                    usersInfo += "<tr class=" + item.ID.ToString() + """>"
                    usersInfo += "<td><a href=""editUser.aspx?ID=" + item.ID.ToString() + """>" + api.getMatrix("Select") + "</a></td>"
                    usersInfo += "<td>" + item.Name + "</td>"
                    usersInfo += "<td>" + item.Email + "</td>"
                    usersInfo += "<td class=""center"">"

                    Select Case item.Role
                        Case api.ADMIN
                            usersInfo += api.getMatrix("Admin") + "</td>"
                        Case api.USER
                            usersInfo += api.getMatrix("User") + "</td>"
                    End Select

                    usersInfo += "<td class=""center"">"

                    If item.Active Then
                        usersInfo += api.getMatrix("Yes") + "</td>"
                    Else
                        usersInfo += api.getMatrix("No") + "</td>"
                    End If

                    usersInfo += "</tr>"


                Next

                usersInfo += "</tbody>"
                usersInfo += "</table>"

                litUserTable.Text = usersInfo
            End If
        End If
    End Sub
End Class