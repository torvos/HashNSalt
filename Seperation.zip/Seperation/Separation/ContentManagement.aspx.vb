﻿Public Class ContentManagement
    Inherits System.Web.UI.Page
    Private api As New API()

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        api.adminCheck()

        litContentManagment.Text = api.getMatrix("ContentManagment")
        lblMatrix.Text = api.getMatrix("Matrix")
        lblMemo.Text = api.getMatrix("Memo")

        Dim lookup As New MatrixDataContext()

        Dim matrixResults = (From Matrix In lookup.Matrix_infos Select Matrix.ID, Matrix.english, Matrix.french)
        Dim memoResults = (From Memo In lookup.Memo_infos Select Memo.ID, Memo.english, Memo.french)

        Dim tableData As String
        tableData = ""

        If matrixResults IsNot Nothing OrElse matrixResults.Count() > 0 Then

            tableData = "<table class=""wb-tables table table-striped table-hover"" data-wb-tables='{ ""ordering"" : true }'>"
            tableData += "<thead>"
            tableData += "<tr>"
            tableData += "<th>" + api.getMatrix("Select") + "</th>"
            tableData += "<th>" + api.getMatrix("English") + "</th>"
            tableData += "<th>" + api.getMatrix("French") + "</th>"
            tableData += "</tr>"
            tableData += "</thead>"
            tableData += "<tbody>"

            For Each item In matrixResults

                tableData += "<tr class=" + item.ID + """>"
                tableData += "<td><a href=""editContent.aspx?Type=Matrix&ID=" + item.ID.ToString() + """>" + api.getMatrix("Select") + "</a></td>"
                tableData += "<td>" + item.english + "</td>"
                tableData += "<td>" + item.french + "</td>"
                tableData += "</tr>"

            Next

            tableData += "</tbody>"
            tableData += "</table>"

            litMatrixTable.Text = tableData

        End If

        If memoResults IsNot Nothing OrElse memoResults.Count() > 0 Then

            tableData = "<table class=""wb-tables table table-striped table-hover"" data-wb-tables='{ ""ordering"" : true }'>"
            tableData += "<thead>"
            tableData += "<tr>"
            tableData += "<th>" + api.getMatrix("Select") + "</th>"
            tableData += "<th>" + api.getMatrix("English") + "</th>"
            tableData += "<th>" + api.getMatrix("French") + "</th>"
            tableData += "</tr>"
            tableData += "</thead>"
            tableData += "<tbody>"

            For Each item In memoResults

                tableData += "<tr class=" + item.ID + """>"
                tableData += "<td><a href=""editContent.aspx?Type=Memo&ID=" + item.ID.ToString() + """>" + api.getMatrix("Select") + "</a></td>"
                tableData += "<td>" + item.english + "</td>"
                tableData += "<td>" + item.french + "</td>"
                tableData += "</tr>"

            Next

            tableData += "</tbody>"
            tableData += "</table>"

            litMemoTable.Text = tableData

        End If

    End Sub

End Class