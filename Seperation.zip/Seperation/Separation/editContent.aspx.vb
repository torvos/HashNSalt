﻿Public Class editContent
    Inherits System.Web.UI.Page
    Private api As New API()

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        api.adminCheck()

        litContentManagment.Text = api.getMatrix("ContentManagment")
        litEnglish.Text = api.getMatrix("English")
        litFrench.Text = api.getMatrix("French")
        btnSubmit.Text = api.getMatrix("Submit")

        If Not Page.IsPostBack Then

            Dim labelID As String
            Dim labelType As String
            labelType = ""
            labelID = ""

            If Request.QueryString("ID") IsNot Nothing Then
                labelID = Request.QueryString("ID")
            Else
                Response.Redirect("ContentManagement.aspx")
            End If

            Dim lookup As New MatrixDataContext()

            If Request.QueryString("Type") IsNot Nothing Then
                If Request.QueryString("Type") = "Matrix" Then
                    Dim results = (From Matrix In lookup.Matrix_infos Where Matrix.ID = labelID Select Matrix.english, Matrix.french)
                    If results Is Nothing OrElse results.Count() = 0 Then
                        Response.Redirect("ContentManagement.aspx")
                    End If
                    txtEnglish.Text = results.FirstOrDefault.english
                    lblEnglish.CssClass = "control-label col-sm-1"
                    txtFrench.Text = results.FirstOrDefault.french
                    lblFrench.CssClass = "control-label col-sm-1"
                ElseIf Request.QueryString("Type") = "Memo" Then
                    Dim results = (From Memo In lookup.Memo_infos Where Memo.ID = labelID Select Memo.english, Memo.french)
                    If results Is Nothing OrElse results.Count() = 0 Then
                        Response.Redirect("ContentManagement.aspx")
                    End If
                    txtEnglish.Text = results.FirstOrDefault.english
                    txtEnglish.TextMode = TextBoxMode.MultiLine
                    txtEnglish.CssClass = "form-control"
                    txtFrench.Text = results.FirstOrDefault.french
                    txtFrench.TextMode = TextBoxMode.MultiLine
                    txtFrench.CssClass = "form-control"

                    Dim script As String = "CKEDITOR.replace( 'mainContent_txtEnglish', { language: 'en-ca',});"
                    Dim script2 As String = "CKEDITOR.replace( 'mainContent_txtFrench', { language: 'en-ca',});"

                    If api.getLanguage() = "fr" Then
                        script = "CKEDITOR.replace( 'mainContent_txtEnglish', { language: 'fr-ca',});"
                        script2 = "CKEDITOR.replace( 'mainContent_txtFrench', { language: 'fr-ca',});"
                    End If

                    If Not Page.ClientScript.IsStartupScriptRegistered(Me.GetType(), "alertscript") Then
                        Page.ClientScript.RegisterStartupScript(Me.GetType(), "alertscript", Script, True)
                    End If
                    If Not Page.ClientScript.IsStartupScriptRegistered(Me.GetType(), "alertscript2") Then
                        Page.ClientScript.RegisterStartupScript(Me.GetType(), "alertscript2", script2, True)
                    End If
                End If
            Else
                Response.Redirect("ContentManagement.aspx")
            End If

        End If

    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim errorFlag = 0
        litErrorText.Visible = False
        If txtEnglish.Text = "" Then
            litErrorText.Text += api.getMatrix("NameError2") + "<br>"
            errorFlag = 1
        End If
        If txtEnglish.Text = "" Then
            litErrorText.Text += api.getMatrix("EmailError3") + "<br>"
            errorFlag = 1
        End If

        If errorFlag = 0 Then

            If Request.QueryString("Type") IsNot Nothing Then
                If Request.QueryString("Type") = "Matrix" Then
                    Dim db As New MatrixDataContext()
                    Dim update As New Matrix_info

                    update = db.Matrix_infos.Single(Function(Matrix_info) Matrix_info.ID = Request.QueryString("ID"))

                    update.english = txtEnglish.Text
                    update.french = txtFrench.Text

                    db.SubmitChanges()

                ElseIf Request.QueryString("Type") = "Memo" Then
                    Dim db As New MatrixDataContext()
                    Dim update As New Memo_info

                    update = db.Memo_infos.Single(Function(Memo_info) Memo_info.ID = Request.QueryString("ID"))

                    update.english = txtEnglish.Text
                    update.french = txtFrench.Text

                    db.SubmitChanges()

                End If
            Else
                Response.Redirect("ContentManagement.aspx")
            End If

            Response.Redirect("ContentManagement.aspx")
        Else
            litErrorText.Text += "<br>"
            litErrorText.Visible = True
        End If
    End Sub
End Class