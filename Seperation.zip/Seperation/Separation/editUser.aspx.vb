﻿Public Class editUser
    Inherits System.Web.UI.Page
    Private api As New API()
    
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim userID As String

        If System.Web.HttpContext.Current.Session IsNot Nothing Then
            If System.Web.HttpContext.Current.Session("usersRole") IsNot Nothing Then
                If Not System.Web.HttpContext.Current.Session("usersRole").Equals(api.ADMIN) Then
                    lblActive.Visible = False
                    ddlActive.Visible = False
                    lblRole.Visible = False
                    ddlRole.Visible = False
                    userID = System.Web.HttpContext.Current.Session("usersID").ToString()
                Else
                    If Request.QueryString("ID") IsNot Nothing Then
                        userID = Request.QueryString("ID")
                    Else
                        Response.Redirect("UserManagement.aspx")
                    End If
                End If
            Else
                System.Web.HttpContext.Current.Response.Redirect("index.aspx")
            End If
        End If

        litEditUser.Text = api.getMatrix("EditUser")
        litName.Text = API.getMatrix("FullName")
        litEmail.Text = API.getMatrix("Email")
        litRole.Text = API.getMatrix("Role")
        litActive.Text = API.getMatrix("Active")
        btnSubmit.Text = api.getMatrix("Submit")

        If Not Page.IsPostBack Then

            Dim lookup As New UsersDataContext()
            Dim results = (From Users In lookup.Users _
                            Where Users.ID.ToString() = userID _
                            Select Users.Name, Users.Email, Users.Role, Users.Active)

            If results Is Nothing OrElse results.Count() = 0 Then
                Response.Redirect("UserManagement.aspx")
            End If

            txtName.Text = results.FirstOrDefault.Name
            txtEmail.Text = results.FirstOrDefault.Email

            Dim userItem As New ListItem
            Dim adminItem As New ListItem
            adminItem.Value = 1
            userItem.Value = 2
            adminItem.Text = api.getMatrix("Admin")
            userItem.Text = api.getMatrix("User")

            Select Case results.FirstOrDefault.Role
                Case api.ADMIN
                    adminItem.Selected = True
                Case api.USER
                    userItem.Selected = True
            End Select

            ddlRole.Items.Add(userItem)
            ddlRole.Items.Add(adminItem)

            Dim trueItem As New ListItem
            Dim falseItem As New ListItem
            falseItem.Value = 0
            trueItem.Value = 1
            trueItem.Text = api.getMatrix("True")
            falseItem.Text = api.getMatrix("False")

            Select Case results.FirstOrDefault.Active
                Case True
                    trueItem.Selected = True
                Case False
                    falseItem.Selected = True
            End Select


            ddlActive.Items.Add(trueItem)
            ddlActive.Items.Add(falseItem)


        End If

    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim errorFlag = 0
        litErrorText.Visible = False
        If txtName.Text = "" Then
            litErrorText.Text += api.getMatrix("NameError2") + "<br>"
            errorFlag = 1
        End If
        If txtEmail.Text = "" Then
            litErrorText.Text += api.getMatrix("EmailError3") + "<br>"
            errorFlag = 1
        Else
            If Not Regex.IsMatch(txtEmail.Text, "^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$") Then
                litErrorText.Text += api.getMatrix("EmailError2") + "<br>"
                errorFlag = 1
            End If
        End If

        If errorFlag = 0 Then
            Dim db As New UsersDataContext()

            Dim updateUser As New User

            If Not System.Web.HttpContext.Current.Session("usersRole").Equals(api.ADMIN) Then
                updateUser = db.Users.Single(Function(User) User.ID.ToString = System.Web.HttpContext.Current.Session("usersID").ToString())
            Else
                updateUser = db.Users.Single(Function(User) User.ID.ToString = Request.QueryString("ID"))
            End If

            updateUser.Name = txtName.Text
            updateUser.Email = txtEmail.Text

            If System.Web.HttpContext.Current.Session IsNot Nothing Then
                If System.Web.HttpContext.Current.Session("usersRole") IsNot Nothing Then
                    If System.Web.HttpContext.Current.Session("usersRole").Equals(api.ADMIN) Then
                        updateUser.Role = ddlRole.SelectedValue
                        updateUser.Active = ddlActive.SelectedValue
                        db.SubmitChanges()
                        Response.Redirect("UserManagement.aspx")
                    End If
                End If
            End If

            db.SubmitChanges()

            System.Web.HttpContext.Current.Session("usersName") = updateUser.Name
            System.Web.HttpContext.Current.Session("usersEmail") = updateUser.Email

            Response.Redirect("index.aspx")
        Else
            litErrorText.Text += "<br>"
            litErrorText.Visible = True
        End If

    End Sub
End Class