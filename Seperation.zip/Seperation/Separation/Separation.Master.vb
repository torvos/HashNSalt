﻿Imports System.Reflection

Public Class Separation
    Inherits System.Web.UI.MasterPage
    Private api As New API()

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        litTitle.Text = api.getMatrix("ApplicationName")
        litENFR.Text = api.getLanguage()
        litENFR2.Text = api.getLanguage()

        If api.getLanguage() = "fr" Then
            litPageTitle.Text = "<a href=""index.aspx"">Processus de séparation</a>"
            linkLangSwitch.Text = "English"
            linkLangSwitch.ToolTip = "English - English version of the Web page"
            linkLangSwitch.Attributes.Add("lang", "en")
            linkLangSwitch.Attributes.Add("xml:lang", "en")
            litDCTerms_language.Text = "<meta name=""dcterms.language"" title=""ISO639-2"" content=""fra""/>"
            litSkipToContent.Text = "Passer au contenu principal"
            litSkipToAbout.Text = "Passer à «&#160;À propos de ce site&#160;»"
            litLangH2.Text = "Sélection de la langue"
            litGoCAsset.Text = "./assets/sig-blk-fr.svg"
            litGoCAssetLabel.Text = "Gouvernement du Canada"
            litGoCLabel.Text = "Symbole du gouvernement du Canada"
            litMenuH2.Text = "Menu des sujets"
            litDateMod.Text = "Date de modification&#160;:&#32;"
            'litBreadH2.Text = "Vous êtes ici :"
            'litHome.Text = "Accueil de l""OPE"
            litFooter.Text = "<h2>À propos de ce site</h2><div class=""row""><section class=""col-sm-3""><h3>Contactez-nous</h3><ul class=""list-unstyled""><li><a href=""contact.aspx"">Questions ou commentaires?</a></li></ul></section><section class=""col-sm-3""><h3>À propos</h3><ul class=""list-unstyled""><li><a href=""about.aspx"">À propos du Processus de séparation</a></li></ul></section></div><ul id=""gc-tctr"" class=""list-inline""><li><a href=""http://rhdcc.prv/fra/aide/index.page"">Avis importants</a></li></ul>"

        Else
            litPageTitle.Text = "<a href=""index.aspx"">Separation Clearance Process</a>"
            linkLangSwitch.Text = "Fran&ccedil;ais"
            linkLangSwitch.ToolTip = "Fran&ccedil;ais - Version fran&ccedil;aise de cette page"
            linkLangSwitch.Attributes.Add("lang", "fr")
            linkLangSwitch.Attributes.Add("xml:lang", "fr")
            litDCTerms_language.Text = "<meta name=""dcterms.language"" title=""ISO639-2"" content=""eng""/>"
            litSkipToContent.Text = "Skip to main content"
            litSkipToAbout.Text = "Skip to ""About this site"""
            litLangH2.Text = "Language selection"
            litGoCAsset.Text = "./assets/sig-blk-en.svg"
            litGoCAssetLabel.Text = "Government of Canada"
            litGoCLabel.Text = "Symbol of the Government of Canada"
            litMenuH2.Text = "Topics menu"
            litDateMod.Text = "Date modified:&#32;"
            'litBreadH2.Text = "You are here:Vous êtes ici :"
            'litHome.Text = "Separation Home"
            litFooter.Text = "<h2>About this site</h2><div class=""row""><section class=""col-sm-3""><h3>Contact us</h3><ul class=""list-unstyled""><li><a href=""contact.aspx"">Questions or comments?</a></li></ul></section><section class=""col-sm-3""><h3>About</h3><ul class=""list-unstyled""><li><a href=""about.aspx"">About the Separation Clearance Process</a></li></ul></section></div><ul id=""gc-tctr"" class=""list-inline""><li><a href=""http://rhdcc.prv/eng/help/index.page"">Important Notices</a></li></ul>"
        End If

        api.checkAuth()

        Dim menuContent As String

        menuContent = "<ul class=""list-inline menu"" runat=""server"" ID=""MainMenu"" role=""menubar"">"

        If System.Web.HttpContext.Current.Session("isUserlogged") Then
            menuContent += "<li><a href=""index.aspx"" class=""item"">" + api.getMatrix("MenuSeparation") + "</a>"
            menuContent += "<ul class=""sm list-unstyled"" id=""project"" role=""menu"">"
            menuContent += "<li><a href=""index.aspx"">" + api.getMatrix("home") + "</a></li>"
            If Not System.Web.HttpContext.Current.Session("usersRole").Equals(api.ADMIN) Then
                menuContent += "<li><a href=""editUser.aspx"">" + api.getMatrix("myInfo") + "</a></li>"
            End If
            menuContent += "</ul>"
            menuContent += "</li>"
        Else
            menuContent += "<li><a href=""index.aspx"" class=""item"">" + api.getMatrix("MenuSeparation") + "</a></li>"
        End If

        If System.Web.HttpContext.Current.Session("usersRole") = api.ADMIN Then
            menuContent += "<li><a class=""item"">" + api.getMatrix("MenuAdministration") + "</a>"
            menuContent += "<ul class=""sm list-unstyled"" id=""project"" role=""menu"">"
            menuContent += "<li><a href=""ContentManagement.aspx"">" + api.getMatrix("ContentManagment") + "</a></li>"
            menuContent += "<li><a href=""UserManagement.aspx"">" + api.getMatrix("MenuManageUsers") + "</a></li>"
            menuContent += "</ul>"
            menuContent += "</li>"
        End If

        menuContent += "</ul>"

        litMenu.Text = menuContent

    End Sub


    Sub linkLangSwitch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles linkLangSwitch.Click
        Dim api As New API()
        If api.getLanguage() = "en" Then
            api.setLanguage("fr")
        Else
            api.setLanguage("en")
        End If
        Response.Redirect(Request.Url.ToString())
    End Sub
End Class






